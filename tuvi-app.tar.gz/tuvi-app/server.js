/**
 * Server chính - Ứng dụng Xem Tử Vi Cá Nhân
 * Stack: Express + iztro + Gemini AI
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { astro } = require('iztro');
const { generateAIReading, hasDeepSeek, hasGeminiKeys, hasAnthropicKey, loadGeminiKeys, getProvider } = require('./server/ai-service');
const { buildPrompt } = require('./server/prompt-builder');
const { mapAstrolabeToVN } = require('./server/astrolabe-mapper');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

/**
 * API: Lập lá số tử vi
 * POST /api/astrolabe
 * Body: { solarDate, timeIndex, gender, name? }
 */
app.post('/api/astrolabe', (req, res) => {
  try {
    let { solarDate, timeIndex, gender, name } = req.body;

    // Validate
    if (!solarDate) {
      return res.status(400).json({ error: 'Vui lòng nhập ngày sinh dương lịch' });
    }

    // Default values
    timeIndex = timeIndex !== undefined && timeIndex !== null && timeIndex !== ''
      ? parseInt(timeIndex) : -1; // -1 = không biết giờ sinh
    gender = gender || '男'; // default male if not specified

    // Map gender string
    const genderMap = { 'nam': '男', 'nu': '女', 'male': '男', 'female': '女', '男': '男', '女': '女' };
    const genderCode = genderMap[gender.toLowerCase()] || '男';

    // Nếu không biết giờ sinh, dùng giờ Tý (index 0) nhưng đánh dấu
    const unknownTime = timeIndex === -1;
    const actualTimeIndex = unknownTime ? 0 : timeIndex;

    // Lập lá số bằng iztro (output tiếng Việt)
    const result = astro.bySolar(solarDate, actualTimeIndex, genderCode, undefined, 'vi-VN');

    // Map sang format tiếng Việt đầy đủ
    const astrolabe = mapAstrolabeToVN(result, {
      solarDate,
      timeIndex: actualTimeIndex,
      unknownTime,
      gender: genderCode === '男' ? 'Nam' : 'Nữ',
      name: name || ''
    });

    res.json({ success: true, data: astrolabe });

  } catch (err) {
    console.error('Lỗi lập lá số:', err);
    res.status(500).json({ error: 'Không thể lập lá số. Vui lòng kiểm tra lại thông tin.' });
  }
});

/**
 * API: AI luận giải tử vi
 * POST /api/reading
 * Body: { astrolabe (from /api/astrolabe response) }
 */
app.post('/api/reading', async (req, res) => {
  try {
    const { astrolabe, topics, customQuestion } = req.body;
    if (!astrolabe) {
      return res.status(400).json({ error: 'Thiếu dữ liệu lá số' });
    }

    // Build prompt từ lá số (with optional topics & custom question)
    const prompt = buildPrompt(astrolabe, topics, customQuestion);

    // Gọi AI luận giải (streaming)
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');

    await generateAIReading(prompt, (chunk) => {
      res.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
    });

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();

  } catch (err) {
    console.error('Lỗi AI luận giải:', err);
    // If headers already sent (streaming), just end
    if (res.headersSent) {
      res.write(`data: ${JSON.stringify({ error: 'Có lỗi xảy ra khi luận giải.' })}\n\n`);
      res.end();
    } else {
      res.status(500).json({ error: 'Không thể luận giải. Vui lòng thử lại.' });
    }
  }
});

/**
 * API: Kiểm tra trạng thái AI
 * GET /api/ai-status
 */
app.get('/api/ai-status', (req, res) => {
  const provider = getProvider();
  res.json({
    aiEnabled: provider !== 'none',
    provider
  });
});

// Catch-all: serve SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  const keyCount = loadGeminiKeys();
  const provider = getProvider();

  console.log(`\n🔮 Tử Vi App đang chạy tại: http://localhost:${PORT}`);
  console.log(`📡 API endpoint: http://localhost:${PORT}/api/astrolabe`);
  console.log(`🤖 AI luận giải: ${provider !== 'none' ? 'BẬT' : 'TẮT'}`);
  if (keyCount > 0) console.log(`🔑 Gemini: ${keyCount} keys [CHÍNH — miễn phí, xoay vòng]`);
  if (hasDeepSeek()) console.log(`💰 DeepSeek: [DỰ PHÒNG — trả phí, khi Gemini hết quota]`);
  console.log('');
});
