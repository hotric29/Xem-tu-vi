/**
 * Astrolabe Mapper - Chuyển đổi dữ liệu iztro sang format tiếng Việt
 * Bao gồm: nạp âm ngũ hành, tam hợp, lục hợp, tứ hành xung
 */

// === NGŨ HÀNH NẠP ÂM (60 Giáp Tý) ===
const NAP_AM = {
  'GiápTý':   'Hải Trung Kim (Vàng trong biển)',
  'ẤtSửu':    'Hải Trung Kim (Vàng trong biển)',
  'BínhDần':  'Lô Trung Hỏa (Lửa trong lò)',
  'ĐinhMão':  'Lô Trung Hỏa (Lửa trong lò)',
  'MậuThìn':  'Đại Lâm Mộc (Gỗ rừng già)',
  'KỷTỵ':     'Đại Lâm Mộc (Gỗ rừng già)',
  'CanhNgọ':  'Lộ Bàng Thổ (Đất ven đường)',
  'TânMùi':   'Lộ Bàng Thổ (Đất ven đường)',
  'NhâmThân': 'Kiếm Phong Kim (Vàng mũi kiếm)',
  'QuýDậu':   'Kiếm Phong Kim (Vàng mũi kiếm)',
  'GiápTuất': 'Sơn Đầu Hỏa (Lửa trên núi)',
  'ẤtHợi':    'Sơn Đầu Hỏa (Lửa trên núi)',
  'BínhTý':   'Giản Hạ Thủy (Nước dưới khe)',
  'ĐinhSửu':  'Giản Hạ Thủy (Nước dưới khe)',
  'MậuDần':   'Thành Đầu Thổ (Đất trên thành)',
  'KỷMão':    'Thành Đầu Thổ (Đất trên thành)',
  'CanhThìn': 'Bạch Lạp Kim (Vàng trong nến)',
  'TânTỵ':    'Bạch Lạp Kim (Vàng trong nến)',
  'NhâmNgọ':  'Dương Liễu Mộc (Gỗ dương liễu)',
  'QuýMùi':   'Dương Liễu Mộc (Gỗ dương liễu)',
  'GiápThân': 'Tuyền Trung Thủy (Nước trong suối)',
  'ẤtDậu':    'Tuyền Trung Thủy (Nước trong suối)',
  'BínhTuất': 'Ốc Thượng Thổ (Đất trên nóc)',
  'ĐinhHợi':  'Ốc Thượng Thổ (Đất trên nóc)',
  'MậuTý':    'Tích Lịch Hỏa (Lửa sấm sét)',
  'KỷSửu':    'Tích Lịch Hỏa (Lửa sấm sét)',
  'CanhDần':  'Tùng Bách Mộc (Gỗ tùng bách)',
  'TânMão':   'Tùng Bách Mộc (Gỗ tùng bách)',
  'NhâmThìn': 'Trường Lưu Thủy (Nước chảy dài)',
  'QuýTỵ':    'Trường Lưu Thủy (Nước chảy dài)',
  'GiápNgọ':  'Sa Trung Kim (Vàng trong cát)',
  'ẤtMùi':    'Sa Trung Kim (Vàng trong cát)',
  'BínhThân': 'Sơn Hạ Hỏa (Lửa dưới núi)',
  'ĐinhDậu':  'Sơn Hạ Hỏa (Lửa dưới núi)',
  'MậuTuất':  'Bình Địa Mộc (Gỗ đồng bằng)',
  'KỷHợi':    'Bình Địa Mộc (Gỗ đồng bằng)',
  'CanhTý':   'Bích Thượng Thổ (Đất trên vách)',
  'TânSửu':   'Bích Thượng Thổ (Đất trên vách)',
  'NhâmDần':  'Kim Bạc Kim (Vàng lá mỏng)',
  'QuýMão':   'Kim Bạc Kim (Vàng lá mỏng)',
  'GiápThìn': 'Phú Đăng Hỏa (Lửa ngọn đèn)',
  'ẤtTỵ':     'Phú Đăng Hỏa (Lửa ngọn đèn)',
  'BínhNgọ':  'Thiên Hà Thủy (Nước sông Ngân)',
  'ĐinhMùi':  'Thiên Hà Thủy (Nước sông Ngân)',
  'MậuThân':  'Đại Dịch Thổ (Đất cái đồn)',
  'KỷDậu':    'Đại Dịch Thổ (Đất cái đồn)',
  'CanhTuất': 'Thoa Xuyến Kim (Vàng trang sức)',
  'TânHợi':   'Thoa Xuyến Kim (Vàng trang sức)',
  'NhâmTý':   'Tang Đố Mộc (Gỗ cây dâu)',
  'QuýSửu':   'Tang Đố Mộc (Gỗ cây dâu)',
  'GiápDần':  'Đại Khê Thủy (Nước khe lớn)',
  'ẤtMão':    'Đại Khê Thủy (Nước khe lớn)',
  'BínhThìn': 'Sa Trung Thổ (Đất trong cát)',
  'ĐinhTỵ':   'Sa Trung Thổ (Đất trong cát)',
  'MậuNgọ':   'Thiên Thượng Hỏa (Lửa trên trời)',
  'KỷMùi':    'Thiên Thượng Hỏa (Lửa trên trời)',
  'CanhThân': 'Thạch Lựu Mộc (Gỗ thạch lựu)',
  'TânDậu':   'Thạch Lựu Mộc (Gỗ thạch lựu)',
  'NhâmTuất': 'Đại Hải Thủy (Nước biển lớn)',
  'QuýHợi':   'Đại Hải Thủy (Nước biển lớn)'
};

// === TAM HỢP (3 con giáp hợp nhau) ===
const TAM_HOP = {
  'Tý': { group: ['Tý', 'Thân', 'Thìn'], element: 'Thủy', desc: 'Tam hợp Thủy cục' },
  'Sửu': { group: ['Sửu', 'Tỵ', 'Dậu'], element: 'Kim', desc: 'Tam hợp Kim cục' },
  'Dần': { group: ['Dần', 'Ngọ', 'Tuất'], element: 'Hỏa', desc: 'Tam hợp Hỏa cục' },
  'Mão': { group: ['Mão', 'Mùi', 'Hợi'], element: 'Mộc', desc: 'Tam hợp Mộc cục' },
  'Thìn': { group: ['Tý', 'Thân', 'Thìn'], element: 'Thủy', desc: 'Tam hợp Thủy cục' },
  'Tỵ': { group: ['Sửu', 'Tỵ', 'Dậu'], element: 'Kim', desc: 'Tam hợp Kim cục' },
  'Ngọ': { group: ['Dần', 'Ngọ', 'Tuất'], element: 'Hỏa', desc: 'Tam hợp Hỏa cục' },
  'Mùi': { group: ['Mão', 'Mùi', 'Hợi'], element: 'Mộc', desc: 'Tam hợp Mộc cục' },
  'Thân': { group: ['Tý', 'Thân', 'Thìn'], element: 'Thủy', desc: 'Tam hợp Thủy cục' },
  'Dậu': { group: ['Sửu', 'Tỵ', 'Dậu'], element: 'Kim', desc: 'Tam hợp Kim cục' },
  'Tuất': { group: ['Dần', 'Ngọ', 'Tuất'], element: 'Hỏa', desc: 'Tam hợp Hỏa cục' },
  'Hợi': { group: ['Mão', 'Mùi', 'Hợi'], element: 'Mộc', desc: 'Tam hợp Mộc cục' }
};

// === LỤC HỢP (2 con giáp hợp nhau) ===
const LUC_HOP = {
  'Tý': { pair: 'Sửu', desc: 'Tý - Sửu hợp Thổ' },
  'Sửu': { pair: 'Tý', desc: 'Sửu - Tý hợp Thổ' },
  'Dần': { pair: 'Hợi', desc: 'Dần - Hợi hợp Mộc' },
  'Mão': { pair: 'Tuất', desc: 'Mão - Tuất hợp Hỏa' },
  'Thìn': { pair: 'Dậu', desc: 'Thìn - Dậu hợp Kim' },
  'Tỵ': { pair: 'Thân', desc: 'Tỵ - Thân hợp Thủy' },
  'Ngọ': { pair: 'Mùi', desc: 'Ngọ - Mùi hợp' },
  'Mùi': { pair: 'Ngọ', desc: 'Mùi - Ngọ hợp' },
  'Thân': { pair: 'Tỵ', desc: 'Thân - Tỵ hợp Thủy' },
  'Dậu': { pair: 'Thìn', desc: 'Dậu - Thìn hợp Kim' },
  'Tuất': { pair: 'Mão', desc: 'Tuất - Mão hợp Hỏa' },
  'Hợi': { pair: 'Dần', desc: 'Hợi - Dần hợp Mộc' }
};

// === TỨ HÀNH XUNG ===
const TU_HANH_XUNG = {
  'Tý': { clash: 'Ngọ', desc: 'Tý xung Ngọ' },
  'Sửu': { clash: 'Mùi', desc: 'Sửu xung Mùi' },
  'Dần': { clash: 'Thân', desc: 'Dần xung Thân' },
  'Mão': { clash: 'Dậu', desc: 'Mão xung Dậu' },
  'Thìn': { clash: 'Tuất', desc: 'Thìn xung Tuất' },
  'Tỵ': { clash: 'Hợi', desc: 'Tỵ xung Hợi' },
  'Ngọ': { clash: 'Tý', desc: 'Ngọ xung Tý' },
  'Mùi': { clash: 'Sửu', desc: 'Mùi xung Sửu' },
  'Thân': { clash: 'Dần', desc: 'Thân xung Dần' },
  'Dậu': { clash: 'Mão', desc: 'Dậu xung Mão' },
  'Tuất': { clash: 'Thìn', desc: 'Tuất xung Thìn' },
  'Hợi': { clash: 'Tỵ', desc: 'Hợi xung Tỵ' }
};

// === CON GIÁP MAP ===
const ZODIAC_EMOJI = {
  'Chuột': '🐀', 'Trâu': '🐃', 'Hổ': '🐅', 'Mèo': '🐈',
  'Rồng': '🐉', 'Rắn': '🐍', 'Ngựa': '🐴', 'Dê': '🐐',
  'Khỉ': '🐒', 'Gà': '🐓', 'Chó': '🐕', 'Lợn': '🐖'
};

// Map zodiac to Địa Chi
const ZODIAC_TO_DIACHI = {
  'Chuột': 'Tý', 'Trâu': 'Sửu', 'Hổ': 'Dần', 'Mèo': 'Mão',
  'Rồng': 'Thìn', 'Rắn': 'Tỵ', 'Ngựa': 'Ngọ', 'Dê': 'Mùi',
  'Khỉ': 'Thân', 'Gà': 'Dậu', 'Chó': 'Tuất', 'Lợn': 'Hợi'
};

// Ngũ hành của Địa Chi
const DIACHI_NGUHANH = {
  'Tý': 'Thủy', 'Sửu': 'Thổ', 'Dần': 'Mộc', 'Mão': 'Mộc',
  'Thìn': 'Thổ', 'Tỵ': 'Hỏa', 'Ngọ': 'Hỏa', 'Mùi': 'Thổ',
  'Thân': 'Kim', 'Dậu': 'Kim', 'Tuất': 'Thổ', 'Hợi': 'Thủy'
};

// Ngũ hành của Thiên Can
const THIENCAN_NGUHANH = {
  'Giáp': 'Mộc', 'Ất': 'Mộc', 'Bính': 'Hỏa', 'Đinh': 'Hỏa',
  'Mậu': 'Thổ', 'Kỷ': 'Thổ', 'Canh': 'Kim', 'Tân': 'Kim',
  'Nhâm': 'Thủy', 'Quý': 'Thủy'
};

// Ngũ hành emoji / color
const NGU_HANH_INFO = {
  'Kim': { emoji: '🪙', color: '#D4AF37', desc: 'Kim - Sắc bén, quyết đoán' },
  'Mộc': { emoji: '🌿', color: '#2D8B46', desc: 'Mộc - Sinh trưởng, nhân từ' },
  'Thủy': { emoji: '💧', color: '#1E90FF', desc: 'Thủy - Linh hoạt, trí tuệ' },
  'Hỏa': { emoji: '🔥', color: '#E74C3C', desc: 'Hỏa - Nhiệt huyết, sáng tạo' },
  'Thổ': { emoji: '🏔️', color: '#B8860B', desc: 'Thổ - Trung thực, bền vững' }
};

/**
 * Lấy nạp âm ngũ hành từ cặp Thiên Can - Địa Chi năm sinh
 */
function getNapAm(chineseDate) {
  // chineseDate format: "Canh Ngọ - Tân Tỵ - Canh Thìn - Mậu Dần"
  const parts = chineseDate.split(' - ');
  if (parts.length < 1) return null;

  const yearPillar = parts[0].replace(/\s/g, ''); // "CanhNgọ"
  return NAP_AM[yearPillar] || null;
}

/**
 * Trích xuất ngũ hành chính từ nạp âm
 */
function getNguHanhFromNapAm(napAm) {
  if (!napAm) return null;
  if (napAm.includes('Kim')) return 'Kim';
  if (napAm.includes('Mộc')) return 'Mộc';
  if (napAm.includes('Thủy')) return 'Thủy';
  if (napAm.includes('Hỏa')) return 'Hỏa';
  if (napAm.includes('Thổ')) return 'Thổ';
  return null;
}

/**
 * Phân tích quan hệ ngũ hành (sinh/khắc)
 */
function getNguHanhRelation(element1, element2) {
  const sinh = {
    'Kim': 'Thủy', 'Thủy': 'Mộc', 'Mộc': 'Hỏa', 'Hỏa': 'Thổ', 'Thổ': 'Kim'
  };
  const khac = {
    'Kim': 'Mộc', 'Mộc': 'Thổ', 'Thổ': 'Thủy', 'Thủy': 'Hỏa', 'Hỏa': 'Kim'
  };

  if (element1 === element2) return { type: 'bình hòa', desc: `${element1} gặp ${element2}: bình hòa, tương trợ` };
  if (sinh[element1] === element2) return { type: 'tương sinh', desc: `${element1} sinh ${element2}` };
  if (sinh[element2] === element1) return { type: 'được sinh', desc: `${element2} sinh ${element1}` };
  if (khac[element1] === element2) return { type: 'tương khắc', desc: `${element1} khắc ${element2}` };
  if (khac[element2] === element1) return { type: 'bị khắc', desc: `${element2} khắc ${element1}` };
  return { type: 'unknown', desc: '' };
}

/**
 * 12 Cung theo thứ tự chuẩn tử vi (bắt đầu từ Dần, đi ngược chiều kim đồng hồ)
 * Layout: 
 *   Tỵ  Ngọ  Mùi  Thân
 *   Thìn              Dậu
 *   Mão               Tuất
 *   Dần  Sửu  Tý   Hợi
 */
const STANDARD_PALACE_ORDER = [
  'Dần', 'Mão', 'Thìn', 'Tỵ', 'Ngọ', 'Mùi',
  'Thân', 'Dậu', 'Tuất', 'Hợi', 'Tý', 'Sửu'
];

// === CHUYỂN ĐỔI NGÀY ÂM LỊCH SANG TIẾNG VIỆT ===
const LUNAR_DAY_VN = {
  1:'Mùng 1',2:'Mùng 2',3:'Mùng 3',4:'Mùng 4',5:'Mùng 5',
  6:'Mùng 6',7:'Mùng 7',8:'Mùng 8',9:'Mùng 9',10:'Mùng 10',
  11:'11',12:'12',13:'13',14:'14',15:'15',16:'16',17:'17',
  18:'18',19:'19',20:'20',21:'21',22:'22',23:'23',24:'24',
  25:'25',26:'26',27:'27',28:'28',29:'29',30:'30'
};

/**
 * Chuyển đổi ngày âm lịch từ iztro (rawDates) sang tiếng Việt
 * Ví dụ: { lunarYear:1991, lunarMonth:3, lunarDay:10, isLeap:false }
 * → "Mùng 10 tháng 3 năm Tân Mùi (1991)"
 */
function lunarDateToVietnamese(rawLunar, chineseDate) {
  if (!rawLunar) return '';
  const { lunarYear, lunarMonth, lunarDay, isLeap } = rawLunar;
  const dayVN = LUNAR_DAY_VN[lunarDay] || lunarDay;
  const leapStr = isLeap ? ' (nhuận)' : '';

  // Lấy Thiên Can Địa Chi năm từ Tứ Trụ
  const yearPillar = chineseDate ? chineseDate.split(' - ')[0] : '';

  return `Ngày ${dayVN} tháng ${lunarMonth}${leapStr} năm ${yearPillar} (${lunarYear})`;
}

/**
 * Map iztro astrolabe sang format Việt Nam đầy đủ
 */
function mapAstrolabeToVN(result, meta) {
  const napAm = getNapAm(result.chineseDate);
  const napAmElement = getNguHanhFromNapAm(napAm);
  const diaChiYear = ZODIAC_TO_DIACHI[result.zodiac] || '';
  const thienCanYear = result.chineseDate.split(' - ')[0].replace(/\s/g, '').slice(0, -result.chineseDate.split(' - ')[0].split(/(?=[A-ZẮẰẲẴẶÂẤẦẨẪẬĂĐÊẾỀỂỄỆÔỐỒỔỖỘƠỚỜỞỠỢƯỨỪỬỮỰÍÌỈĨỊÚÙỦŨỤÉÈẺẼẸÓÒỎÕỌÁÀẢÃẠ])/g).pop().length);

  // Parse Tứ Trụ (4 pillars)
  const tuTru = result.chineseDate.split(' - ');

  // Palaces mapped with grid position
  const palaces = result.palaces.map((p, i) => ({
    index: p.index,
    name: p.name,
    isBodyPalace: p.isBodyPalace,
    isOriginalPalace: p.isOriginalPalace || false,
    isSoulPalace: p.name === 'Mệnh',
    heavenlyStem: p.heavenlyStem,
    earthlyBranch: p.earthlyBranch,
    majorStars: p.majorStars.map(s => ({
      name: s.name,
      brightness: s.brightness || '',
      mutagen: s.mutagen || ''
    })),
    minorStars: p.minorStars.map(s => ({
      name: s.name,
      brightness: s.brightness || '',
      type: s.type || ''
    })),
    adjectiveStars: (p.adjectiveStars || []).map(s => ({
      name: s.name,
      type: s.type || ''
    })),
    changsheng12: p.changsheng12 || '',
    boshi12: p.boshi12 || '',
    decadal: p.decadal || null,
    ages: p.ages || []
  }));

  // Tìm cung Mệnh và cung Thân
  const soulPalace = palaces.find(p => p.name === 'Mệnh');
  const bodyPalace = palaces.find(p => p.isBodyPalace);

  // Tính Tam Hợp, Lục Hợp, Tứ Hành Xung cho năm sinh
  const tamHop = TAM_HOP[diaChiYear] || null;
  const lucHop = LUC_HOP[diaChiYear] || null;
  const tuHanhXung = TU_HANH_XUNG[diaChiYear] || null;

  return {
    // Thông tin cơ bản
    meta: {
      name: meta.name,
      gender: meta.gender,
      solarDate: meta.solarDate,
      unknownTime: meta.unknownTime,
      timeIndex: meta.timeIndex
    },

    // Thông tin âm lịch & Tứ Trụ
    lunarInfo: {
      lunarDate: lunarDateToVietnamese(result.rawDates?.lunarDate, result.chineseDate),
      lunarDateRaw: result.lunarDate,
      chineseDate: result.chineseDate,
      tuTru: {
        year: tuTru[0] || '',
        month: tuTru[1] || '',
        day: tuTru[2] || '',
        hour: tuTru[3] || ''
      }
    },

    // Con giáp & Cung hoàng đạo
    zodiac: {
      animal: result.zodiac,
      emoji: ZODIAC_EMOJI[result.zodiac] || '',
      diaChi: diaChiYear,
      sign: result.sign
    },

    // Ngũ hành & Nạp âm
    fiveElements: {
      napAm: napAm,
      napAmElement: napAmElement,
      napAmInfo: napAmElement ? NGU_HANH_INFO[napAmElement] : null,
      cuc: result.fiveElementsClass,
      diaChiElement: DIACHI_NGUHANH[diaChiYear] || '',
    },

    // Mệnh - Thân
    soulBody: {
      soul: result.soul,
      body: result.body,
      soulPalacePosition: result.earthlyBranchOfSoulPalace,
      bodyPalacePosition: result.earthlyBranchOfBodyPalace,
    },

    // Giờ sinh
    time: {
      label: result.time,
      range: result.timeRange,
      unknown: meta.unknownTime
    },

    // Hợp - Xung
    compatibility: {
      tamHop: tamHop,
      lucHop: lucHop,
      tuHanhXung: tuHanhXung
    },

    // 12 Cung
    palaces: palaces
  };
}

module.exports = { mapAstrolabeToVN, NAP_AM, TAM_HOP, LUC_HOP, TU_HANH_XUNG, NGU_HANH_INFO };
