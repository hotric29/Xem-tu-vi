/**
 * Prompt Builder v2 - Supports topic selection & custom questions
 * Emotional flow: trung thực + minh bạch + hóa giải + khích lệ
 */

const TOPIC_MAP = {
  'tong-quan': 'Tổng Quan Lá Số (cách cục, đặc điểm nổi bật, điểm mạnh/yếu)',
  'tinh-duyen': 'Tình Duyên & Hôn Nhân (cung Phu Thê, cung Mệnh, các sao đào hoa)',
  'cong-viec': 'Sự Nghiệp & Công Việc (cung Quan Lộc, xu hướng nghề, phát triển)',
  'tai-chinh': 'Tài Chính & Đầu Tư (cung Tài Bạch, cách kiếm tiền, quản lý tài sản)',
  'suc-khoe': 'Sức Khỏe & Thể Chất (cung Tật Ách, điểm cần lưu ý)',
  'tam-linh': 'Tâm Linh & Phong Thủy (hóa giải sao xấu, phương hướng tốt, màu sắc may mắn)',
  'hoc-van': 'Học Vấn & Phát Triển (cung Phúc Đức, khả năng học hành, nghiên cứu)',
  'van-han': 'Vận Hạn & Lưu Niên (đại hạn, các giai đoạn quan trọng, năm cần chú ý)',
  'con-cai': 'Con Cái & Hậu Vận (cung Tử Nữ, vấn đề con cái)',
  'gia-dinh': 'Gia Đình & Huyết Thống (cung Phụ Mẫu, Huynh Đệ, quan hệ gia đình)',
  'quy-nhan': 'Quý Nhân & Tiểu Nhân (sao Thiên Khôi, Thiên Việt, Tả Phù, Hữu Bật, người giúp đỡ)',
  'nha-cua': 'Nhà Cửa & Bất Động Sản (cung Điền Trạch, hướng nhà, mua bán đất đai)'
};

function buildPrompt(astrolabe, topics, customQuestion) {
  const { meta, lunarInfo, zodiac, fiveElements, soulBody, time, compatibility, palaces } = astrolabe;

  // Build 12 cung details
  const palaceDetails = palaces.map(p => {
    const stars = [
      ...p.majorStars.map(s => `${s.name}${s.brightness?' ('+s.brightness+')':''}${s.mutagen?' ['+s.mutagen+']':''}`),
      ...p.minorStars.map(s => `${s.name}${s.brightness?' ('+s.brightness+')':''}`),
    ].join(', ');
    const adj = p.adjectiveStars.map(s => s.name).join(', ');
    const dec = p.decadal ? `${p.decadal.range[0]}-${p.decadal.range[1]} tuổi` : '';
    return `- **${p.name}** [${p.heavenlyStem}${p.earthlyBranch}]${p.isBodyPalace?' (Cung Thân)':''}${p.isSoulPalace?' (Cung Mệnh)':''}:
  Chính tinh: ${stars || 'Không có'}
  Phụ tinh: ${adj || 'Không có'}
  Trường Sinh: ${p.changsheng12 || 'N/A'}
  Đại hạn: ${dec}`;
  }).join('\n');

  // Selected topics
  const selectedTopics = (topics && topics.length > 0) 
    ? topics.map(t => TOPIC_MAP[t] || t).join('\n- ')
    : Object.values(TOPIC_MAP).join('\n- ');

  const prompt = `Bạn là một vị Thầy tử vi đẩu số hàng đầu Việt Nam, uyên thâm và nhân hậu. Bạn xưng "Thầy" và gọi người xem là "Con" hoặc "${meta.name || 'bạn'}". Phong cách luận giải:
- TRUNG THỰC: Nói đúng sự thật từ lá số, không xu nịnh, không hù dọa gây hoang mang
- MINH BẠCH: Giải thích rõ TẠI SAO dựa trên bằng chứng cụ thể từ sao/cung trong lá số
- NHÂN VĂN: 
  + Lá số có sao xấu → nhận diện → phân tích nguyên nhân → hướng dẫn hóa giải cụ thể → khích lệ phấn đấu
  + Lá số tốt → ghi nhận ưu điểm → cảnh tỉnh không chủ quan → chỉ ra cách phát huy
- LOGIC NHẤT QUÁN: Phân tích từ đầu đến cuối không mâu thuẫn giữa các cung, các sao phải tương tác đúng

=== THÔNG TIN LÁ SỐ ===
${meta.name ? `Họ tên: ${meta.name}` : ''}
Giới tính: ${meta.gender}
Ngày sinh dương lịch: ${meta.solarDate}
${time.unknown ? '⚠️ KHÔNG BIẾT GIỜ SINH (tính theo giờ Tý mặc định — tham khảo)' : `Giờ sinh: ${time.label} (${time.range})`}

=== ÂM LỊCH & TỨ TRỤ ===
Âm lịch: ${lunarInfo.lunarDate}
Tứ trụ: ${lunarInfo.chineseDate}
- Trụ Năm: ${lunarInfo.tuTru.year} | Trụ Tháng: ${lunarInfo.tuTru.month} | Trụ Ngày: ${lunarInfo.tuTru.day} | Trụ Giờ: ${lunarInfo.tuTru.hour}

=== CON GIÁP & NGŨ HÀNH ===
Con giáp: ${zodiac.animal} (${zodiac.diaChi}) | Cung hoàng đạo: ${zodiac.sign}
Nạp âm: ${fiveElements.napAm || 'N/A'} | Ngũ hành: ${fiveElements.napAmElement || 'N/A'}
Cục: ${fiveElements.cuc}

=== MỆNH - THÂN ===
Chủ tinh Mệnh: ${soulBody.soul} | Chủ tinh Thân: ${soulBody.body}
Cung Mệnh tại: ${soulBody.soulPalacePosition} | Cung Thân tại: ${soulBody.bodyPalacePosition}

=== HỢP - XUNG ===
${compatibility.tamHop ? `Tam hợp: ${compatibility.tamHop.desc}` : ''}
${compatibility.lucHop ? `Lục hợp: ${compatibility.lucHop.desc}` : ''}
${compatibility.tuHanhXung ? `Tứ hành xung: ${compatibility.tuHanhXung.desc}` : ''}

=== CHI TIẾT 12 CUNG ===
${palaceDetails}

=== YÊU CẦU LUẬN GIẢI ===
Hãy luận giải CÁC LĨNH VỰC SAU (viết tiếng Việt, dùng markdown, xưng Thầy/Con):
- ${selectedTopics}

${customQuestion ? `\n=== CÂU HỎI RIÊNG CỦA NGƯỜI XEM ===\n"${customQuestion}"\nHãy trả lời câu hỏi này DỰA TRÊN lá số, phân tích cụ thể sao/cung liên quan.\n` : ''}

${time.unknown ? '\n⚠️ QUAN TRỌNG: Người xem KHÔNG BIẾT GIỜ SINH. Nhấn mạnh kết quả chỉ tham khảo, khuyến khích xác nhận giờ sinh. Tập trung phân tích yếu tố ít phụ thuộc giờ sinh.\n' : ''}

Mỗi phần bắt đầu bằng ## tiêu đề có emoji. Viết tự nhiên, giải thích thuật ngữ khi cần. Khi gặp sao xấu, LUÔN hướng dẫn cách hóa giải. Kết thúc với tông tích cực, khích lệ. Độ dài: chi tiết nhưng đọc được trong 5-8 phút.`;

  return prompt;
}

module.exports = { buildPrompt };
