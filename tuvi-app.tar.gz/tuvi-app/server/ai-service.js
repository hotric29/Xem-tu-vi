/**
 * AI Service v4 — Gemini 10 keys (chính) + DeepSeek (dự phòng trả phí)
 * Thứ tự ưu tiên: Gemini round-robin → chờ 5s retry → DeepSeek fallback
 */
const https = require('https');

// === GEMINI KEY ROTATION ===
let geminiKeys = [];
let currentKeyIndex = 0;

function loadGeminiKeys() {
  geminiKeys = [];
  for (let i = 1; i <= 50; i++) {
    const key = process.env[`GEMINI_KEY_${i}`];
    if (key && key.trim() && key !== 'your_key_here') geminiKeys.push(key.trim());
  }
  const single = process.env.GEMINI_API_KEY;
  if (geminiKeys.length === 0 && single && single.trim() && single !== 'your_gemini_api_key_here') {
    geminiKeys.push(single.trim());
  }
  if (geminiKeys.length > 0) console.log(`🔑 Gemini: ${geminiKeys.length} key(s) [CHÍNH]`);
  return geminiKeys.length;
}

function getNextGeminiKey() {
  if (geminiKeys.length === 0) return null;
  const key = geminiKeys[currentKeyIndex % geminiKeys.length];
  currentKeyIndex = (currentKeyIndex + 1) % geminiKeys.length;
  return key;
}

// === PROVIDER DETECTION ===
function hasGeminiKeys() {
  if (geminiKeys.length === 0) loadGeminiKeys();
  return geminiKeys.length > 0;
}

function hasDeepSeek() {
  const k = process.env.DEEPSEEK_API_KEY;
  return k && k.trim() && !k.includes('PASTE') && !k.includes('your_') && k.startsWith('sk-');
}

function hasAnthropicKey() {
  const k = process.env.ANTHROPIC_API_KEY;
  return k && k.trim() && k !== 'your_anthropic_api_key_here';
}

function getProvider() {
  if (hasGeminiKeys()) return 'gemini';
  if (hasDeepSeek()) return 'deepseek';
  if (hasAnthropicKey()) return 'anthropic';
  return 'none';
}

// === MAIN ENTRY ===
async function generateAIReading(prompt, onChunk) {
  // Ưu tiên 1: Gemini (miễn phí)
  if (hasGeminiKeys()) {
    try {
      return await generateWithGeminiRetry(prompt, onChunk);
    } catch (err) {
      console.log(`⚠️ Gemini thất bại: ${err.message}`);
      // Ưu tiên 2: DeepSeek (trả phí, dự phòng)
      if (hasDeepSeek()) {
        console.log(`🔄 Chuyển sang DeepSeek (dự phòng trả phí)...`);
        onChunk('\n\n🔄 *Đang chuyển sang AI dự phòng...*\n\n');
        try {
          return await generateWithDeepSeek(prompt, onChunk);
        } catch (dsErr) {
          console.log(`❌ DeepSeek cũng thất bại: ${dsErr.message}`);
          throw dsErr;
        }
      }
      throw err;
    }
  }

  // Nếu không có Gemini, dùng DeepSeek trực tiếp
  if (hasDeepSeek()) {
    return await generateWithDeepSeek(prompt, onChunk);
  }

  if (hasAnthropicKey()) {
    return await generateWithAnthropic(prompt, onChunk);
  }

  throw new Error('Chưa cấu hình API key nào. Thêm GEMINI_KEY_1 hoặc DEEPSEEK_API_KEY vào .env');
}

// ============================================================
// GEMINI — Round-robin 10 keys + retry
// ============================================================
async function generateWithGeminiRetry(prompt, onChunk, attempt = 0, round = 1) {
  const maxAttempts = geminiKeys.length;

  if (attempt >= maxAttempts) {
    if (round === 1) {
      // Round 2: chờ 5s rồi thử lại tất cả keys
      console.log(`⏳ Round 1 hết keys. Chờ 5s rồi thử lại (round 2)...`);
      await new Promise(r => setTimeout(r, 5000));
      return generateWithGeminiRetry(prompt, onChunk, 0, 2);
    }
    if (round === 2) {
      // Round 3: thử model nhẹ hơn
      console.log(`⏳ Round 2 hết. Thử gemini-2.0-flash-lite...`);
      try {
        return await generateWithGeminiFallbackModel(prompt, onChunk);
      } catch (e) {
        console.log(`❌ Flash-lite cũng thất bại: ${e.message}`);
      }
    }
    throw new Error('Tất cả Gemini keys bị rate limit.');
  }

  const apiKey = getNextGeminiKey();
  if (!apiKey) throw new Error('Không có Gemini key');

  const keyNum = (currentKeyIndex === 0 ? geminiKeys.length : currentKeyIndex);
  if (attempt === 0 && round === 1) console.log(`🔮 Gemini key #${keyNum}/${geminiKeys.length}`);

  try {
    await generateWithGemini(prompt, onChunk, apiKey);
  } catch (err) {
    if (err.statusCode === 429 || err.statusCode === 503) {
      if (attempt === 0) console.log(`⚠️ Key #${keyNum} → ${err.statusCode}, xoay vòng (round ${round})...`);
      return generateWithGeminiRetry(prompt, onChunk, attempt + 1, round);
    }
    throw err;
  }
}

async function generateWithGeminiFallbackModel(prompt, onChunk) {
  for (let i = 0; i < geminiKeys.length; i++) {
    try {
      await generateWithGemini(prompt, onChunk, geminiKeys[i], 'gemini-2.0-flash-lite');
      return;
    } catch (err) {
      if (err.statusCode === 429 || err.statusCode === 503) continue;
      throw err;
    }
  }
  throw new Error('Flash-lite cũng bị limit');
}

async function generateWithGemini(prompt, onChunk, apiKey, modelOverride) {
  const model = modelOverride || process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${apiKey}`;

  const body = JSON.stringify({
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.7, topP: 0.9, topK: 40, maxOutputTokens: 8192 },
    safetySettings: [
      { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
      { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' }
    ]
  });

  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const req = https.request({
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, (res) => {
      if (res.statusCode !== 200) {
        let errData = '';
        res.on('data', d => errData += d);
        res.on('end', () => {
          const err = new Error(`Gemini ${res.statusCode}: ${errData.substring(0, 200)}`);
          err.statusCode = res.statusCode;
          reject(err);
        });
        return;
      }
      let buffer = '';
      res.on('data', (chunk) => {
        buffer += chunk.toString();
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim();
            if (data === '[DONE]') continue;
            try { const t = JSON.parse(data)?.candidates?.[0]?.content?.parts?.[0]?.text; if (t) onChunk(t); } catch (e) {}
          }
        }
      });
      res.on('end', () => {
        if (buffer.startsWith('data: ')) {
          try { const t = JSON.parse(buffer.slice(6).trim())?.candidates?.[0]?.content?.parts?.[0]?.text; if (t) onChunk(t); } catch (e) {}
        }
        resolve();
      });
      res.on('error', reject);
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ============================================================
// DEEPSEEK (dự phòng trả phí — OpenAI-compatible)
// ============================================================
async function generateWithDeepSeek(prompt, onChunk) {
  const apiKey = process.env.DEEPSEEK_API_KEY.trim();
  const model = process.env.DEEPSEEK_MODEL || 'deepseek-chat';

  const body = JSON.stringify({
    model,
    messages: [
      { role: 'system', content: 'Bạn là chuyên gia tử vi đẩu số hàng đầu Việt Nam. Trả lời bằng tiếng Việt, dùng markdown.' },
      { role: 'user', content: prompt }
    ],
    stream: true,
    temperature: 0.7,
    max_tokens: 8192
  });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.deepseek.com',
      path: '/chat/completions',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Content-Length': Buffer.byteLength(body)
      }
    }, (res) => {
      if (res.statusCode !== 200) {
        let errData = '';
        res.on('data', d => errData += d);
        res.on('end', () => {
          const err = new Error(`DeepSeek ${res.statusCode}: ${errData.substring(0, 300)}`);
          err.statusCode = res.statusCode;
          reject(err);
        });
        return;
      }
      let buffer = '';
      res.on('data', (chunk) => {
        buffer += chunk.toString();
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim();
            if (data === '[DONE]') continue;
            try { const t = JSON.parse(data)?.choices?.[0]?.delta?.content; if (t) onChunk(t); } catch (e) {}
          }
        }
      });
      res.on('end', () => {
        if (buffer.startsWith('data: ') && buffer.slice(6).trim() !== '[DONE]') {
          try { const t = JSON.parse(buffer.slice(6).trim())?.choices?.[0]?.delta?.content; if (t) onChunk(t); } catch (e) {}
        }
        resolve();
      });
      res.on('error', reject);
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ============================================================
// ANTHROPIC (optional)
// ============================================================
async function generateWithAnthropic(prompt, onChunk) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  const model = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514';
  const body = JSON.stringify({ model, max_tokens: 8192, messages: [{ role: 'user', content: prompt }], stream: true });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.anthropic.com', path: '/v1/messages', method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'Content-Length': Buffer.byteLength(body) }
    }, (res) => {
      if (res.statusCode !== 200) { let e=''; res.on('data',d=>e+=d); res.on('end',()=>reject(new Error(`Anthropic ${res.statusCode}: ${e}`))); return; }
      let buffer = '';
      res.on('data', (chunk) => {
        buffer += chunk.toString(); const lines = buffer.split('\n'); buffer = lines.pop() || '';
        for (const line of lines) { if (line.startsWith('data: ')) { try { const p=JSON.parse(line.slice(6).trim()); if(p.type==='content_block_delta'&&p.delta?.text) onChunk(p.delta.text); } catch(e){} } }
      });
      res.on('end', resolve);
      res.on('error', reject);
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

module.exports = { generateAIReading, hasDeepSeek, hasGeminiKeys, hasAnthropicKey, loadGeminiKeys, getProvider };
