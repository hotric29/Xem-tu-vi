/**
 * Tử Vi Đẩu Số — Frontend v2
 * Matches xem-tuvi.com reference UX
 */
(function(){
'use strict';
const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);

let currentAstrolabe = null;

// === INIT ===
document.addEventListener('DOMContentLoaded', () => {
  generateStarField();
  populateFormDropdowns();
  setupEvents();
  checkAiStatus();
  showRandomQuote();
});

// Famous quotes about destiny
const QUOTES = [
  'Biết mệnh mà không chịu mệnh, đó mới là người trí',
  'Thiên hành kiện, quân tử dĩ tự cường bất tức',
  'Đức năng thắng số, thiện năng thắng họa',
  'Mệnh do thiên định, vận do ngã tạo',
  'Phúc bất đường hưởng, họa bất đơn hành'
];

function showRandomQuote(){
  const q = QUOTES[Math.floor(Math.random()*QUOTES.length)];
  const el = $('#heroQuote');
  if(el) el.innerHTML = `"${q}" <span style="color:var(--text-dim)">— Cổ nhân</span>`;
}

// === Star Field ===
function generateStarField(){
  const f=$('#starField'); if(!f) return;
  for(let i=0;i<70;i++){
    const s=document.createElement('div');
    s.className='star';
    s.style.left=Math.random()*100+'%';
    s.style.top=Math.random()*100+'%';
    s.style.setProperty('--dur',(2+Math.random()*5)+'s');
    s.style.setProperty('--op',(0.3+Math.random()*0.7));
    s.style.animationDelay=Math.random()*5+'s';
    const sz=1+Math.random()*2;
    s.style.width=sz+'px';s.style.height=sz+'px';
    f.appendChild(s);
  }
}

// === Form Dropdowns ===
function populateFormDropdowns(){
  const daySelect=$('#birthDay');
  const monthSelect=$('#birthMonth');
  for(let d=1;d<=31;d++){daySelect.add(new Option(d,d))}
  for(let m=1;m<=12;m++){monthSelect.add(new Option(m,m))}
}

// === Events ===
function setupEvents(){
  // Submit
  $('#btnSubmit').addEventListener('click', handleSubmit);

  // Disclaimer
  $('#btnUnderstand').addEventListener('click', () => {
    $('#disclaimerModal').style.display='none';
    showResults();
  });

  // About
  $('#btnAbout').addEventListener('click', () => {$('#aboutModal').style.display='flex'});
  $('#btnCloseAbout').addEventListener('click', () => {$('#aboutModal').style.display='none'});

  // Back
  $('#btnBack').addEventListener('click', handleBack);
  $('#btnNewReading').addEventListener('click', handleBack);

  // AI topics
  $$('.topic-tag').forEach(tag => {
    tag.addEventListener('click', () => tag.classList.toggle('active'));
  });

  // Quick questions
  $$('.quick-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.dataset.q;
      const ta = $('#aiCustomQuestion');
      ta.value = q;
      updateCharCount();
    });
  });

  // Char count
  $('#aiCustomQuestion').addEventListener('input', updateCharCount);

  // AI reading
  $('#btnAiReading').addEventListener('click', handleAiReading);

  // Close modals on overlay click
  $$('.modal-overlay').forEach(m => {
    m.addEventListener('click', e => {
      if(e.target === m) m.style.display='none';
    });
  });
}

function updateCharCount(){
  const ta=$('#aiCustomQuestion');
  $('#charCount').textContent = ta.value.length+'/200';
}

// === Check AI Status ===
async function checkAiStatus(){
  try {
    const res = await fetch('/api/ai-status');
    const data = await res.json();
    if(data.aiEnabled){
      $('#btnAiReading').style.display='block';
      $('#aiDisabledMsg').style.display='none';
    } else {
      $('#btnAiReading').style.display='none';
      $('#aiDisabledMsg').style.display='block';
    }
  } catch(e){
    $('#btnAiReading').style.display='none';
    $('#aiDisabledMsg').style.display='block';
  }
}

// === Submit ===
async function handleSubmit(){
  const day = parseInt($('#birthDay').value);
  const month = parseInt($('#birthMonth').value);
  const year = parseInt($('#birthYear').value);
  const timeIndex = parseInt($('#timeIndex').value);
  const gender = $('#gender').value;
  const name = $('#userName').value.trim();

  // Validate
  if(!year || year < 1920 || year > 2025){
    alert('Vui lòng nhập năm sinh hợp lệ (1920-2025)');
    return;
  }
  if(!day || !month){
    alert('Vui lòng chọn ngày và tháng sinh');
    return;
  }

  // Format date
  const solarDate = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;

  // Validate date
  const testDate = new Date(solarDate);
  if(isNaN(testDate.getTime()) || testDate.getDate() !== day){
    alert('Ngày sinh không hợp lệ. Vui lòng kiểm tra lại.');
    return;
  }

  // Show loading
  showLoading();

  try {
    // Animate loading steps
    await delay(600);
    setLoadingStep('Đang xem xét Tứ Trụ...','Phân tích Thiên Can Địa Chi');
    await delay(500);

    const res = await fetch('/api/astrolabe', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({solarDate, timeIndex, gender, name})
    });
    const result = await res.json();

    if(!result.success) throw new Error(result.error || 'Có lỗi xảy ra');

    currentAstrolabe = result.data;

    setLoadingStep('Đang xem xét Cung Mệnh & Cung Thân...','Phân tích chính tinh, phụ tinh tọa thủ');
    await delay(700);
    setLoadingStep('Hoàn tất lá số!','Đang chuẩn bị hiển thị...');
    await delay(400);

    hideLoading();

    // Show disclaimer first
    $('#disclaimerModal').style.display='flex';

  } catch(err){
    hideLoading();
    alert('Lỗi: '+err.message);
  }
}

function delay(ms){return new Promise(r=>setTimeout(r,ms))}

function showLoading(){
  $('#loadingOverlay').style.display='flex';
  setLoadingStep('Đang lập lá số...','Tính toán vị trí các sao');
}
function hideLoading(){$('#loadingOverlay').style.display='none'}
function setLoadingStep(text,sub){
  $('#loadingText').textContent=text;
  $('#loadingSub').textContent=sub;
}

// === Show Results ===
function showResults(){
  if(!currentAstrolabe) return;
  const d = currentAstrolabe;

  // Top bar
  const nameStr = d.meta.name ? d.meta.name+' — ' : '';
  const timeStr = d.time.unknown ? '' : ' · '+d.time.label;
  $('#topbarInfo').textContent = `${nameStr}${d.meta.solarDate} | ${d.meta.gender}`;

  // Render all sections
  renderOverview(d);
  renderAstrolabe(d);
  renderCompat(d);

  // Reset AI
  $('#aiResult').style.display='none';
  $('#aiResultBody').innerHTML='';
  checkAiStatus();

  // Show
  $('#hero').style.display='none';
  $('#results').style.display='block';
  window.scrollTo(0,0);
}

function handleBack(){
  $('#results').style.display='none';
  $('#hero').style.display='flex';
  window.scrollTo(0,0);
}

// === Render Overview ===
function renderOverview(d){
  const napAmShort = d.fiveElements.napAm ? d.fiveElements.napAm.split('(')[0].trim() : '—';
  const napAmDetail = d.fiveElements.napAm ? (d.fiveElements.napAm.match(/\((.+)\)/)||[])[1]||'' : '';
  const napAmElement = d.fiveElements.napAmElement || '';

  // Tứ trụ year parts
  const yearPillar = d.lunarInfo.tuTru.year || '';
  const timeStr = d.time.unknown ? '(Chưa biết giờ)' : d.time.label + ' (' + d.time.range + ')';

  // Cuc description
  const cucDesc = getCucDescription(d.fiveElements.cuc);

  $('#overviewCard').innerHTML = `
    <div class="overview-top">
      <div class="overview-yinyang">☯</div>
      <div class="overview-date">${d.meta.gender} · ${d.meta.solarDate} · ${d.time.unknown ? 'Chưa biết giờ' : d.time.label}</div>
      <div class="overview-lunar">${d.lunarInfo.lunarDate}</div>
    </div>

    <div class="overview-grid">
      <div class="overview-cell">
        <div class="ov-label">MỆNH NẠP ÂM</div>
        <div class="ov-value highlight-gold">${napAmShort}</div>
        <div class="ov-sub">${napAmElement}${yearPillar ? ' · '+yearPillar : ''}</div>
      </div>
      <div class="overview-cell">
        <div class="ov-label">MỆNH CỤC</div>
        <div class="ov-value">${d.fiveElements.cuc}</div>
      </div>
      <div class="overview-cell">
        <div class="ov-label">CHỦ MỆNH</div>
        <div class="ov-value">${d.soulBody.soul}</div>
      </div>
      <div class="overview-cell">
        <div class="ov-label">CHỦ THÂN</div>
        <div class="ov-value">${d.soulBody.body}</div>
      </div>
      <div class="overview-cell">
        <div class="ov-label">CON GIÁP</div>
        <div class="ov-value">${d.zodiac.animal}</div>
      </div>
      <div class="overview-cell">
        <div class="ov-label">CUNG HOÀNG ĐẠO</div>
        <div class="ov-value">${d.zodiac.sign}</div>
      </div>
    </div>

    <div class="overview-explain">
      <div class="explain-block">
        <h4>Mệnh Nạp Âm — ${napAmShort} (${napAmElement})</h4>
        <p>Mệnh theo Nạp Âm Ngũ Hành, phụ thuộc năm sinh âm lịch ${yearPillar}. ${napAmDetail ? '(' + napAmDetail + ')' : ''}</p>
      </div>
      <div class="explain-block">
        <h4>Mệnh Cục — ${d.fiveElements.cuc}</h4>
        <p>${cucDesc}</p>
      </div>
    </div>
  `;
}

function getCucDescription(cuc){
  const map = {
    'Thủy Nhị Cục': 'Lá số thuộc Thủy Nhị Cục (Cục số 2) — linh hoạt, thông minh, giỏi thích ứng. Như nước uốn lượn, luôn tìm ra lối đi.',
    'Mộc Tam Cục': 'Lá số thuộc Mộc Tam Cục (Cục số 3) — nhân hậu, kiên cường, phát triển bền vững. Như cây xanh tươi, càng lớn càng vững.',
    'Kim Tứ Cục': 'Lá số thuộc Kim Tứ Cục (Cục số 4) — quyết đoán, cứng rắn, có nguyên tắc. Mạnh mẽ và bền bỉ như kim loại.',
    'Thổ Ngũ Cục': 'Lá số thuộc Thổ Ngũ Cục (Cục số 5) — trung thực, điềm tĩnh, bao dung. Vững chãi và đáng tin cậy như đất.',
    'Hỏa Lục Cục': 'Lá số thuộc Hỏa Lục Cục (Cục số 6) — nhiệt huyết, sáng tạo, hành động nhanh. Rực rỡ và mạnh mẽ như lửa.'
  };
  return map[cuc] || 'Cục quyết định tốc độ vận hành và phong cách cuộc đời.';
}

// === Render Astrolabe Grid ===
function renderAstrolabe(d){
  if(d.time.unknown){$('#timeWarning').style.display='block'}
  else{$('#timeWarning').style.display='none'}

  const palaces = d.palaces;
  const palaceByBranch = {};
  palaces.forEach(p => {palaceByBranch[p.earthlyBranch] = p});

  // Grid order: top-left to bottom-right
  const gridOrder = [
    'Tỵ','Ngọ','Mùi','Thân',
    'Thìn','__C__','__C__','Dậu',
    'Mão','__C__','__C__','Tuất',
    'Dần','Sửu','Tý','Hợi'
  ];

  let html = '';
  let centerDone = false;

  gridOrder.forEach(branch => {
    if(branch === '__C__'){
      if(!centerDone){
        html += renderCenter(d);
        centerDone = true;
      }
      return;
    }
    const palace = palaceByBranch[branch];
    if(palace){
      html += renderPalace(palace);
    } else {
      html += `<div class="palace-cell"><span class="palace-name">${branch}</span></div>`;
    }
  });

  $('#astrolabeGrid').innerHTML = html;
}

function renderPalace(p){
  const isSoul = p.name === 'Mệnh';
  const isBody = p.isBodyPalace;
  const isOriginal = p.isOriginalPalace;
  let cls = 'palace-cell';
  if(isSoul) cls += ' is-soul';
  if(isBody && !isSoul) cls += ' is-body';

  let tags = '';
  if(isOriginal) tags += '<span class="lainhan-tag">Lai Nhân</span>';
  if(isSoul) tags += '<span class="soul-tag">MỆNH</span>';
  if(isBody) tags += '<span class="body-tag">Thân</span>';

  // Major stars with color-coded brightness (red text, green/blue brightness)
  const majorHTML = p.majorStars.map(s => {
    let h = `<span>${s.name}</span>`;
    if(s.brightness){
      const bc = getBrightnessClass(s.brightness);
      h += `<span class="star-brightness ${bc}">${s.brightness}</span>`;
    }
    if(s.mutagen){
      h += ` <span class="star-mutagen">${s.mutagen}</span>`;
    }
    return `<div class="star-major">${h}</div>`;
  }).join('');

  // Minor stars (blue)
  const minorParts = p.minorStars.map(s => {
    let h = s.name;
    if(s.brightness){
      const bc = getBrightnessClass(s.brightness);
      h += `<span class="star-brightness ${bc}">${s.brightness}</span>`;
    }
    return h;
  });
  const minorHTML = minorParts.length ? `<div class="star-minor">${minorParts.join('  ')}</div>` : '';

  // Adjective stars (small gray)
  const adjHTML = p.adjectiveStars.length
    ? `<div class="star-adjective">${p.adjectiveStars.map(s=>s.name).join('  ')}</div>` : '';

  // Footer: changsheng + boshi on left, decadal on right
  const dec = p.decadal ? `${p.decadal.range[0]}-${p.decadal.range[1]}` : '';
  const cs = p.changsheng12 || '';
  const bs = p.boshi12 || '';

  return `<div class="${cls}">
    <div class="palace-header">
      <span class="palace-name">${p.name}${tags}</span>
      <span class="palace-branch">${p.earthlyBranch}</span>
    </div>
    <div class="palace-stars">${majorHTML}${minorHTML}${adjHTML}</div>
    <div class="palace-footer">
      <span class="palace-changsheng">${cs}</span>
      <span class="palace-boshi">${bs}</span>
    </div>
  </div>`;
}

function getBrightnessClass(b){
  const map = {'Miếu':'bright-mieu','Vượng':'bright-vuong','Đắc':'bright-dac','Lợi':'bright-loi','Bình':'bright-binh','Bất':'bright-bat','Hạn':'bright-han'};
  return map[b]||'';
}

function renderCenter(d){
  const tt = d.lunarInfo.tuTru;
  return `<div class="palace-cell palace-center">
    <div class="center-title">Lá Số Tử Vi</div>
    <div class="center-grid">
      <span class="cg-label">NGÀY SINH DL</span>
      <span class="cg-value">${d.meta.solarDate} (${d.time.unknown?'Chưa biết giờ':d.time.label})</span>
      <span class="cg-label">NGÀY SINH ÂL</span>
      <span class="cg-value">${d.lunarInfo.lunarDate}</span>
      <span class="cg-label">TỨ TRỤ</span>
      <span class="cg-value">${tt.year} - ${tt.month} - ${tt.day} - ${tt.hour}</span>
      <div class="cg-span"></div>
      <span class="cg-label">MỆNH NẠP ÂM</span>
      <span class="cg-value gold">${d.fiveElements.napAm ? d.fiveElements.napAm.split('(')[0].trim()+' ('+d.fiveElements.napAmElement+')' : '—'}</span>
      <span class="cg-label">MỆNH CỤC</span>
      <span class="cg-value">${d.fiveElements.cuc}</span>
      <span class="cg-label">CHỦ MỆNH</span>
      <span class="cg-value">${d.soulBody.soul}</span>
      <span class="cg-label">CHỦ THÂN</span>
      <span class="cg-value">${d.soulBody.body}</span>
      <span class="cg-label">CON GIÁP</span>
      <span class="cg-value">${d.zodiac.emoji} ${d.zodiac.animal}</span>
      <span class="cg-label">CUNG HĐ</span>
      <span class="cg-value">${d.zodiac.sign}</span>
    </div>
  </div>`;
}

// === Render Compatibility ===
function renderCompat(d){
  const {tamHop, lucHop, tuHanhXung} = d.compatibility;
  const animalMap = {'Tý':'Chuột','Sửu':'Trâu','Dần':'Hổ','Mão':'Mèo','Thìn':'Rồng','Tỵ':'Rắn','Ngọ':'Ngựa','Mùi':'Dê','Thân':'Khỉ','Dậu':'Gà','Tuất':'Chó','Hợi':'Lợn'};
  let html = '';

  if(tamHop){
    const animals = tamHop.group.map(g=>`${animalMap[g]||g} (${g})`).join(', ');
    html += `<div class="compat-card"><h3>🤝 Tam Hợp</h3><p><span class="compat-highlight">${tamHop.desc}</span></p><p>Tuổi ${d.zodiac.animal} thuộc nhóm tam hợp: ${animals}. Ba tuổi này hỗ trợ, hợp tác tốt.</p></div>`;
  }
  if(lucHop){
    html += `<div class="compat-card"><h3>💞 Lục Hợp</h3><p><span class="compat-highlight">${lucHop.desc}</span></p><p>Tuổi ${d.zodiac.animal} lục hợp với tuổi ${animalMap[lucHop.pair]||lucHop.pair} (${lucHop.pair}). Cặp đôi hòa hợp, dễ đồng cảm.</p></div>`;
  }
  if(tuHanhXung){
    html += `<div class="compat-card"><h3>⚡ Tứ Hành Xung</h3><p><span class="compat-highlight">${tuHanhXung.desc}</span></p><p>Tuổi ${d.zodiac.animal} xung với tuổi ${animalMap[tuHanhXung.clash]||tuHanhXung.clash} (${tuHanhXung.clash}). Cần kiên nhẫn và bao dung để hóa giải.</p></div>`;
  }

  $('#compatSection').innerHTML = html;
}

// === AI Reading ===
async function handleAiReading(){
  if(!currentAstrolabe) return;

  // Get selected topics
  const topics = [];
  $$('.topic-tag.active').forEach(t => topics.push(t.dataset.topic));
  const customQ = $('#aiCustomQuestion').value.trim();

  const btn = $('#btnAiReading');
  btn.disabled = true;
  btn.querySelector('.btn-text').style.display='none';
  btn.querySelector('.btn-loading').style.display='inline-flex';

  const resultEl = $('#aiResult');
  const bodyEl = $('#aiResultBody');
  resultEl.style.display='block';
  bodyEl.innerHTML='<span class="ai-cursor"></span>';

  // Scroll to result
  resultEl.scrollIntoView({behavior:'smooth',block:'start'});

  try {
    const res = await fetch('/api/reading', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        astrolabe: currentAstrolabe,
        topics,
        customQuestion: customQ
      })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';
    let buffer = '';

    while(true){
      const {done, value} = await reader.read();
      if(done) break;

      buffer += decoder.decode(value, {stream:true});
      const lines = buffer.split('\n');
      buffer = lines.pop()||'';

      for(const line of lines){
        if(line.startsWith('data: ')){
          try {
            const data = JSON.parse(line.slice(6));
            if(data.text){
              fullText += data.text;
              bodyEl.innerHTML = renderMarkdown(fullText) + '<span class="ai-cursor"></span>';
            }
            if(data.done) bodyEl.innerHTML = renderMarkdown(fullText);
            if(data.error) bodyEl.innerHTML += `<p style="color:var(--red)">❌ ${data.error}</p>`;
          } catch(e){}
        }
      }
    }
    bodyEl.innerHTML = renderMarkdown(fullText);

  } catch(err){
    bodyEl.innerHTML = `<p style="color:var(--red)">❌ Lỗi: ${err.message}</p>`;
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').style.display='inline';
    btn.querySelector('.btn-loading').style.display='none';
  }
}

// === Markdown Renderer ===
function renderMarkdown(t){
  if(!t) return '';
  let h = t
    .replace(/^### (.+)$/gm,'<h3>$1</h3>')
    .replace(/^## (.+)$/gm,'<h2>$1</h2>')
    .replace(/^# (.+)$/gm,'<h2>$1</h2>')
    .replace(/\*\*\*(.+?)\*\*\*/g,'<strong><em>$1</em></strong>')
    .replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>')
    .replace(/\*(.+?)\*/g,'<em>$1</em>')
    .replace(/^[-*] (.+)$/gm,'<li>$1</li>')
    .replace(/\n\n/g,'</p><p>')
    .replace(/\n/g,'<br>');
  h='<p>'+h+'</p>';
  h=h.replace(/(<li>.*?<\/li>)+/gs,m=>'<ul>'+m+'</ul>');
  h=h.replace(/<p>\s*<\/p>/g,'');
  h=h.replace(/<p>\s*(<h[23]>)/g,'$1');
  h=h.replace(/(<\/h[23]>)\s*<\/p>/g,'$1');
  h=h.replace(/<p>\s*(<ul>)/g,'$1');
  h=h.replace(/(<\/ul>)\s*<\/p>/g,'$1');
  return h;
}

})();
