#!/bin/bash
# =====================================================
# TỬ VI ĐẨU SỐ — Cài đặt tự động hoàn chỉnh
# Domain: tuvi.hoductri.com
# SSH Port: 24700
# AI: Gemini (chính) → DeepSeek (dự phòng)
# =====================================================
set -e

DOMAIN="tuvi.hoductri.com"
SSH_PORT=24700

echo ""
echo "🔮 ============================================"
echo "   TỬ VI ĐẨU SỐ — Cài đặt tự động"
echo "   Domain: $DOMAIN | SSH port: $SSH_PORT"
echo "   ============================================"
echo ""

export DEBIAN_FRONTEND=noninteractive

# ======== 1) MỞ FIREWALL TRƯỚC — QUAN TRỌNG NHẤT ========
echo "🔓 [1/7] Mở firewall (giữ kết nối SSH)..."
# Mở TẤT CẢ port cần thiết TRƯỚC khi enable UFW
ufw allow $SSH_PORT/tcp comment 'SSH custom port'
ufw allow 22/tcp comment 'SSH default'
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'
ufw allow 3000/tcp comment 'Node.js app'
# Enable firewall (--force để không hỏi confirm)
ufw --force enable
echo "✅ Firewall đã mở port: $SSH_PORT, 22, 80, 443, 3000"
ufw status
echo ""

# ======== 2) Cập nhật hệ thống ========
echo "📦 [2/7] Cập nhật hệ thống..."
apt update -y && apt upgrade -y
echo "✅ Xong"
echo ""

# ======== 3) Cài Node.js 20 ========
echo "📦 [3/7] Cài Node.js 20..."
if command -v node &> /dev/null; then
    echo "   Node.js đã có: $(node -v)"
else
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt install -y nodejs
    echo "✅ Node.js $(node -v)"
fi
echo ""

# ======== 4) Cài PM2 ========
echo "📦 [4/7] Cài PM2..."
npm install -g pm2 2>/dev/null || true
echo "✅ PM2 sẵn sàng"
echo ""

# ======== 5) Cài dependencies + chạy app ========
echo "📦 [5/7] Cài thư viện + khởi chạy app..."
cd /opt/tuvi-app
npm install --production

pm2 stop tuvi-app 2>/dev/null || true
pm2 delete tuvi-app 2>/dev/null || true
pm2 start server.js --name tuvi-app
pm2 startup -u root --hp /root 2>/dev/null || pm2 startup 2>/dev/null || true
pm2 save
echo "✅ App đang chạy trên port 3000"
echo ""

# ======== 6) Cài Nginx ========
echo "🌐 [6/7] Cài Nginx + cấu hình domain..."
apt install -y nginx

cat > /etc/nginx/sites-available/tuvi << NGEOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;

        # Quan trọng cho AI streaming
        proxy_buffering off;
        proxy_read_timeout 300s;
    }
}
NGEOF

rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/tuvi /etc/nginx/sites-enabled/tuvi
nginx -t && systemctl restart nginx
echo "✅ Nginx OK — domain: $DOMAIN"
echo ""

# ======== 7) Cài SSL ========
echo "🔒 [7/7] Cài SSL (HTTPS)..."
apt install -y certbot python3-certbot-nginx
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email 2>/dev/null || {
    echo ""
    echo "⚠️ SSL chưa cài được (DNS có thể chưa trỏ về IP này)."
    echo "   Sau khi DNS OK, chạy lệnh:"
    echo "   certbot --nginx -d $DOMAIN"
    echo ""
}

# ======== KẾT QUẢ ========
SERVER_IP=$(hostname -I | awk '{print $1}')
echo ""
echo "🎉 ============================================"
echo "   CÀI ĐẶT HOÀN TẤT!"
echo "   ============================================"
echo ""
echo "   🌐 Website: https://$DOMAIN"
echo "   🌐 Backup:  http://$SERVER_IP"
echo "   🔌 SSH:     ssh -p $SSH_PORT root@$SERVER_IP"
echo ""
echo "   🔑 AI: Gemini 10 keys [CHÍNH]"
echo "   💰 AI: DeepSeek [DỰ PHÒNG khi Gemini hết quota]"
echo ""
echo "   📋 Lệnh quản lý:"
echo "      pm2 logs tuvi-app       # Xem log"
echo "      pm2 restart tuvi-app    # Restart app"
echo "      pm2 status              # Trạng thái"
echo ""
echo "   🔒 Cài SSL thủ công (nếu cần):"
echo "      certbot --nginx -d $DOMAIN"
echo ""
echo "   📊 Log hiện tại:"
pm2 logs tuvi-app --lines 8 --nostream 2>/dev/null || true
echo ""
